from my_fraction import Fraction

f1 = Fraction(5,2)
f2 = Fraction(3,4)

print("Add:", f1 + f2)
print("Sub:", f1 - f2)
print("Mul:", f1 * f2)
print("Div:", f1 / f2)

