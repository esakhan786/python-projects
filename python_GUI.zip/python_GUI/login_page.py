from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox

# Login function
def handle_login():
    email = email_input.get()
    password = password_input.get()
    
    if email == 'esak62622@gmail.com' and password == '123':
        messagebox.showinfo('Yayyy', 'Login Successful')
    else:
        messagebox.showerror('Error', 'Login Failed')
        email_input.delete(0, END)
        password_input.delete(0, END)

# Main window
root = Tk()
root.title("Login Page")
root.geometry('350x500')
root.configure(background='#0096DC')

# Icon
root.iconbitmap('log.ico')

# Logo Image
img = Image.open('LOGO CUI.webp')
resized_img = img.resize((100, 100))
img = ImageTk.PhotoImage(resized_img)
Label(root, image=img, bg='#0096DC').pack(pady=(20,10))

# Title
Label(root, text='Login Page', fg='white', bg='#0096DC', font=('verdana', 24, 'bold')).pack(pady=(0,20))

# Email
Label(root, text='Enter Email', fg='white', bg='#0096DC', font=('verdana', 12)).pack(pady=(10,5))
email_input = Entry(root, width=35, font=('verdana', 12))
email_input.pack(ipady=6, pady=(0,15))

# Password
Label(root, text='Enter Password', fg='white', bg='#0096DC', font=('verdana', 12)).pack(pady=(10,5))
password_input = Entry(root, width=35, font=('verdana', 12), show="*")
password_input.pack(ipady=6, pady=(0,15))

# Sign In Button
Button(root, text='Sign In', width=20, height=2, bg='white', fg='black', font=('verdana', 10), command=handle_login).pack(pady=(10,20))

root.mainloop()
