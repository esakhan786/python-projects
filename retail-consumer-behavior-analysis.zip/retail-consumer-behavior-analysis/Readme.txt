# Pakistani Retail Sales Data Analysis

## Project Overview
This project involved a comprehensive Exploratory Data Analysis (EDA) of a retail sales dataset. I performed a data migration and transformation process to localize an Indian sales dataset into a Pakistani market context, followed by deep-dive analysis to uncover purchasing patterns based on gender, age, and geography.

## Key Features
* **Data Transformation (ETL):** Converted regional data, customer naming conventions, and currency contexts to Pakistani demographics.
* **Data Cleaning:** Handled missing values (Amount column), dropped redundant features, and corrected data types.
* **Exploratory Data Analysis:** Utilized Python (Pandas/Seaborn) to identify that female customers in the 26-35 age group are the primary revenue drivers.
* **Visualizations:** Created bar charts and count plots to represent sales distribution across provinces like Punjab and Sindh.

## Technologies Used
* **Language:** Python
* **Libraries:** Pandas, NumPy, Seaborn, Matplotlib
* **Tools:** Jupyter Notebook 

## How to Run
1. Clone the repository.
2. Install dependencies: `pip install pandas seaborn matplotlib`.
3. Run the analysis notebook: `jupyter notebook analysis.ipynb`.