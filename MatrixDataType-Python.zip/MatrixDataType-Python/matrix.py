class Matrix:
    def __init__(self, data):
        self.data = data
        self.rows = len(data)
        self.cols = len(data[0])

    def __str__(self):
        result = ""
        for row in self.data:
            result += str(row) + "\n"
        return result

    # Addition
    def __add__(self, other):
        if self.rows != other.rows or self.cols != other.cols:
            raise ValueError("Matrices must be of same size for addition")
        result = []
        for i in range(self.rows):
            row = [self.data[i][j] + other.data[i][j] for j in range(self.cols)]
            result.append(row)
        return Matrix(result)

    # Subtraction
    def __sub__(self, other):
        if self.rows != other.rows or self.cols != other.cols:
            raise ValueError("Matrices must be of same size for subtraction")
        result = []
        for i in range(self.rows):
            row = [self.data[i][j] - other.data[i][j] for j in range(self.cols)]
            result.append(row)
        return Matrix(result)

    # Multiplication
    def __mul__(self, other):
        if self.cols != other.rows:
            raise ValueError("Number of columns of first matrix must equal rows of second matrix")
        result = []
        for i in range(self.rows):
            row = []
            for j in range(other.cols):
                sum = 0
                for k in range(self.cols):
                    sum += self.data[i][k] * other.data[k][j]
                row.append(sum)
            result.append(row)
        return Matrix(result)

    # Transpose
    def transpose(self):
        result = []
        for j in range(self.cols):
            row = [self.data[i][j] for i in range(self.rows)]
            result.append(row)
        return Matrix(result)

    # Determinant (only for 2x2)
    def determinant(self):
        if self.rows != self.cols:
            raise ValueError("Determinant is only defined for square matrices")
        if self.rows == 2:
            return self.data[0][0]*self.data[1][1] - self.data[0][1]*self.data[1][0]
        else:
            raise NotImplementedError("Determinant implemented only for 2x2 matrices")


        
            