from matrix import Matrix

m1 = Matrix([[1,2],[3,4]])
m2 = Matrix([[5,6],[7,8]])

print("Matrix 1:")
print(m1)

print("Matrix 2:")
print(m2)

print("Addition:")
print(m1 + m2)

print("Subtraction:")
print(m1 - m2)

print("Multiplication:")
print(m1 * m2)

print("Transpose of Matrix 1:")
print(m1.transpose())

print("Determinant of Matrix 1:")
print(m1.determinant())
