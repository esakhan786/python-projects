import math

class Vector:
    def __init__(self, components):
        self.components = components
        self.dimension = len(components)

    def __str__(self):
        return f"Vector({self.components})"

    # Addition
    def __add__(self, other):
        if self.dimension != other.dimension:
            raise ValueError("Vectors must be of the same dimension")
        result = [a+b for a,b in zip(self.components, other.components)]
        return Vector(result)

    # Subtraction
    def __sub__(self, other):
        if self.dimension != other.dimension:
            raise ValueError("Vectors must be of the same dimension for subtraction")
        result = [a-b for a,b in zip(self.components, other.components)]
        return Vector(result)

    # Scalar multiplication
    def __mul__(self, scalar):
        if isinstance(scalar, (int,float)):
            result = [scalar*x for x in self.components]
            return Vector(result)
        else:
            raise ValueError("Can only multiply vector by a scalar")

    __rmul__ = __mul__  # allows 2*v as well as v*2

    # Dot product
    def dot(self, other):
        if self.dimension != other.dimension:
            raise ValueError("Vectors must be of the same dimension for dot product")
        return sum(a*b for a,b in zip(self.components, other.components))

    # Cross product (only 3D)
    def cross(self, other):
        if self.dimension != 3 or other.dimension != 3:
            raise ValueError("Cross product is defined only for 3D vectors")
        a1,a2,a3 = self.components
        b1,b2,b3 = other.components
        result = [
            a2*b3 - a3*b2,
            a3*b1 - a1*b3,
            a1*b2 - a2*b1
        ]
        return Vector(result)

    # Magnitude
    def magnitude(self):
        return math.sqrt(sum(x**2 for x in self.components))

    # Normalize
    def normalize(self):
        mag = self.magnitude()
        if mag == 0:
            raise ValueError("Cannot normalize zero vector")
        return self * (1/mag)

    # Equality
    def __eq__(self, other):
        return self.components == other.components
