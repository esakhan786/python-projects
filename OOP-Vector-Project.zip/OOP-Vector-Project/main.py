from vector import Vector

v1 = Vector([1, 2, 3])
v2 = Vector([4, 5, 6])

print("Vector 1:", v1)
print("Vector 2:", v2)

print("\nAddition:", v1 + v2)
print("Subtraction:", v1 - v2)
print("Scalar Multiplication v1*2:", v1*2)
print("Dot Product:", v1.dot(v2))
print("Cross Product:", v1.cross(v2))
print("Magnitude of v1:", v1.magnitude())
print("Normalized v1:", v1.normalize())
print("Equality v1==v2:", v1==v2)
