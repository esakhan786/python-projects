from oopatm import Atm

obj = Atm()
