import io
import webbrowser
import requests
from tkinter import *
from urllib.request import urlopen
from PIL import ImageTk,Image

class NewsApp:

    def __init__(self):

        self.data = requests.get('https://newsapi.org/v2/top-headlines?country=us&apiKey=07ce6431517e45c5b04b589c36e5bed6').json()

        self.load_gui()
        self.load_news_item(0)
        self.root.mainloop()   # ✅ moved here

    def load_gui(self):
        self.root = Tk()
        self.root.geometry('350x600')
        self.root.resizable(0,0)
        self.root.title('Mera News App')
        self.root.configure(background='black')

    def clear(self):
        for i in self.root.pack_slaves():
            i.destroy()

    def load_news_item(self,index):

        # ✅ safety check
        if index < 0 or index >= len(self.data['articles']):
            return

        self.clear()

        article = self.data['articles'][index]

        # image
        try:
            img_url = article.get('urlToImage')
            if img_url:
                raw_data = urlopen(img_url).read()
                im = Image.open(io.BytesIO(raw_data)).resize((350,250))
            else:
                raise Exception()

        except:
            img_url = 'https://www.hhireb.com/wp-content/uploads/2019/08/default-no-img.jpg'
            raw_data = urlopen(img_url).read()
            im = Image.open(io.BytesIO(raw_data)).resize((350,250))

        photo = ImageTk.PhotoImage(im)

        label = Label(self.root,image=photo)
        label.image = photo
        label.pack()

        heading = Label(self.root,
                        text=article.get('title',"No Title"),
                        bg='black',fg='white',
                        wraplength=350,justify='center')
        heading.pack(pady=(10,20))
        heading.config(font=('verdana',15))

        details = Label(self.root,
                        text=article.get('description',"No Description"),
                        bg='black',fg='white',
                        wraplength=350,justify='center')
        details.pack(pady=(2,20))
        details.config(font=('verdana',12))

        frame = Frame(self.root,bg='black')
        frame.pack(expand=True,fill=BOTH)

        if index != 0:
            prev = Button(frame,text='Prev',width=16,height=3,
                          command=lambda :self.load_news_item(index-1))
            prev.pack(side=LEFT)

        read = Button(frame, text='Read More', width=16, height=3,
                      command=lambda :self.open_link(article.get('url')))
        read.pack(side=LEFT)

        if index != len(self.data['articles'])-1:
            next = Button(frame, text='Next', width=16, height=3,
                          command=lambda :self.load_news_item(index+1))
            next.pack(side=LEFT)

    def open_link(self,url):
        if url:
            webbrowser.open(url)

obj = NewsApp()
