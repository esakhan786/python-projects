from tkinter import *
from PIL import Image, ImageTk
import os

def rotate_img():
    global counter
    label.config(image=img_arr[counter%len(img_arr)])
    counter+=1

counter=1
root = Tk()
root.title('Wallpaper Viewer')
root.geometry('250x400')
root.configure(background='black')

img_arr = []

for file in os.listdir():
    if file.endswith(('.png', '.jpg', '.jpeg')):
        img = Image.open(file)
        resized_img = img.resize((200,300))
        img_arr.append(ImageTk.PhotoImage(resized_img))

label = Label(root, image=img_arr[0], bg='black')
label.pack(pady=(15,10))

next_btn=Button(root,text='Next',bg='white',fg='black',width=28,height=2,command=rotate_img)
next_btn.pack()


root.mainloop()
